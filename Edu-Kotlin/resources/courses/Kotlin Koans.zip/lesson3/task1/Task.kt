package task1

fun Shop.getSetOfCustomers(): Set<Customer> = TODO()