class LazyProperty(val initializer: () -> Int) {
    val lazyValue: Int by TODO()
}

