package task2

class LazyProperty(val initializer: () -> Int) {
    
    val lazy: Int
        get() {
            TODO()
        }
}
