package task2

class LazyProperty(val initializer: () -> Int) {
    /* TODO */
    val lazy: Int
        get() {
            TODO()
        }
}
