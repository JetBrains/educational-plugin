package task5

fun containsEven(collection: Collection<Int>): Boolean = collection.any { TODO() }