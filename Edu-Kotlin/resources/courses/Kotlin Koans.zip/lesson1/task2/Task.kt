fun toJSON(collection: Collection<Int>): String = TODO()
