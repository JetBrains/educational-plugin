package task13

fun getList(): List<Int> {
    return arrayListOf(1, 5, 2).TODO("return the list sorted in descending order")
}