package lesson1.task1.tests

import util.*

fun main(args: Array<String>) {
    val helper = TestHelper(args)
	helper.run_common_tests()
}