package lesson1.task3

// default values for arguments:
fun bar(i: Int, s: String = "", b: Boolean = true) {}

fun usage() {
    // named arguments:
    bar(1, b = false)
}

fun joinFunction(collection: Collection<Int>): String {
    return collection.joinToString(specify arguments correctly)
}