package lesson1.task3.tests

import lesson1.task3.joinFunction
import util.*


fun main(args: Array<String>) {
    val helper = TestHelper(args)
    helper.run_common_tests()
    helper.testEquals("{1, 2, 3, 42, 555}", joinFunction(listOf(1, 2, 3, 42, 555)),
            "rewrittenFunction should return the same result as javaFunction")
}