package lesson1.task3

fun joinOptions(options: Collection<String>) = options.joinToString(TODO())