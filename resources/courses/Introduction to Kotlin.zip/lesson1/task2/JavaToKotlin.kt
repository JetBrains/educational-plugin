package lesson1.task2


fun rewrittenFunction(collection: Collection<Int>): String {
	//paste code in java instead
}

fun task1(collection: Collection<Int>): String {
    return rewrittenFunction(collection)
}
