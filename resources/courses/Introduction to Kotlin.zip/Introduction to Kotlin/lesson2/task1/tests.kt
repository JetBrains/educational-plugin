package lesson2.task1.tests

import TestHelper

fun testAnswerPlaceholders(helper: TestHelper) {
    val placeholders: Array<String> = helper.answerPlaceholders
    val placeholder = placeholders[0]
    if (placeholder.equals("it.orders.size"))
        helper.passed()
    else
        helper.failed()
}

fun main(args: Array<String>) {
    val helper = TestHelper(args)
    testAnswerPlaceholders(helper)
}