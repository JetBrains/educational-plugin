package lesson2.task1

import course_collections.*

fun Shop.getCustomersSortedByNumberOfOrders(): List<Customer> = customers.sortedBy { /* put answer here */ }

fun main(args: Array<String>) {
    val customers: List<Customer> = shop.getCustomersSortedByNumberOfOrders()
    for (customer in customers) {
        print(customer)
    }
}