package lesson1.task2.tests

import util.*

fun testAnswerPlaceholders(helper: TestHelper) {
    val placeholders = helper.get_answer_placeholders()
    val placeholder = placeholders.get(0)
    if (placeholder.equals("year - other.year"))
        helper.passed()
    else
        helper.failed()
}

fun main(args: Array<String>) {
    val helper = TestHelper(args)
    helper.run_common_tests()
	testAnswerPlaceholders(helper)
}