package lesson1.task2.tests

import TestHelper

fun testAnswerPlaceholders(helper: TestHelper) {
    val placeholders: Array<String> = helper.answerPlaceholders
    val placeholder = placeholders[0]
    if (placeholder.equals("year - other.year"))
        helper.passed()
    else
        helper.failed()
}

fun main(args: Array<String>) {
    val helper = TestHelper(args)
    testAnswerPlaceholders(helper)
}