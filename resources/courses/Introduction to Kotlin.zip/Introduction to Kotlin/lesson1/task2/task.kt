package lesson1.task2

data class MyDate(val year: Int) : Comparable<MyDate> {
    override fun compareTo(other: MyDate) = /* put answer here */
}

fun compare(date1: MyDate, date2: MyDate) = date1 < date2

fun main(args: Array<String>) {
    val first = MyDate(2014)
    val second = MyDate(2015)
    print(first < second)
}