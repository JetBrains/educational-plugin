package lesson1.task1

fun main(args: Array<String>) {
    println("Hello")
}