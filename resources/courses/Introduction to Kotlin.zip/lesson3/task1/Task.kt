package lesson3.task1

fun Shop.getSetOfCustomers(): Set<Customer> = TODO()