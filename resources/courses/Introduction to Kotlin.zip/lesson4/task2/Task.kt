package lesson4.task2

class LazyProperty(val initializer: () -> Int) {
       
    val lazy: Int
        get() {
            TODO()
        }
}
