package lesson4.task3

class LazyProperty(val initializer: () -> Int) {
    val lazyValue: Int by TODO()
}

