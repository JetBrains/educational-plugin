package lesson1.task2

fun toJSON(collection: Collection<Int>): String = TODO()
