package lesson1.task1

fun start(): String = TODO()